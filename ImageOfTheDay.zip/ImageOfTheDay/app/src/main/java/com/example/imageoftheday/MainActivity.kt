package com.example.imageoftheday

import android.app.DatePickerDialog.OnDateSetListener
import android.content.Intent
import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.fragment.app.DialogFragment
import com.android.volley.*
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import com.squareup.picasso.Picasso
import org.json.JSONException
import java.text.DateFormat
import java.util.*

class MainActivity : AppCompatActivity(), OnDateSetListener {
    private val TAG = "MainActivity"
    private var mTextViewExplanation: TextView? = null
    private var mTextViewDatePicker: TextView? = null
    private var mTextViewSuggest: TextView? = null
    private var mTextViewTitle: TextView? = null
    private var mTextViewMetadataDate: TextView? = null
    private var mButtonParse: Button? = null
    private var mButtonSelectDateButton: Button? = null
    private var mButtonDarkMode: Button? = null
    private var mImageView: ImageView? = null
    private var mImageViewSelectSecondActivity: ImageView? = null
    private var mImageViewAddIntoFavorites: ImageView? = null
    private var mQueue: RequestQueue? = null
    private var mCurrentDateString: String? = null
    private var mCurrentDateFormatInput: String? = null
    private var mUrlRequestForJson: String? = null
    private var isNightModeOn = false
    protected fun setmFavoriteList(jsonLink: String?) {
        mFavoriteList.add(jsonLink)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Dark mode preferences
//        mButtonDarkMode = findViewById<Button>(R.id.darkMode)
        val prefDarkMode = getSharedPreferences(NIGHT_MODE, MODE_PRIVATE)
        val editorDarkMode = prefDarkMode.edit()
        isNightModeOn = prefDarkMode.getBoolean(NIGHT_MODE, false)
        if (isNightModeOn) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            mButtonDarkMode!!.setText("Light Mode")
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            mButtonDarkMode!!.setText("Dark Mode")
        }
        // Start from the last opened date
        mUrlRequestForJsonLastActive = PrefConfig.retrieveLastRequest(
            applicationContext
        )
        mButtonDarkMode!!.setOnClickListener(View.OnClickListener {
            if (isNightModeOn) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
                editorDarkMode.putBoolean(NIGHT_MODE, false)
                mButtonDarkMode!!.setText("Light Mode")
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
                editorDarkMode.putBoolean(NIGHT_MODE, true)
                mButtonDarkMode!!.setText("Dark Mode")
            }
            editorDarkMode.apply()
        })
//        mTextViewExplanation = findViewById(R.id.textViewExplanation)
        mTextViewExplanation!!.setMovementMethod(ScrollingMovementMethod())
//        mTextViewDatePicker = findViewById(R.id.textViewDatePicker)
//        mTextViewSuggest = findViewById(R.id.textViewSuggest)
//        mButtonParse = findViewById(R.id.buttonParse)
//        mImageView = findViewById(R.id.imageViewResult)

        // Open Favorites Activity
//        mImageViewSelectSecondActivity = findViewById(R.id.selectSecondActivity)
        mImageViewSelectSecondActivity!!.setOnClickListener(View.OnClickListener { openRecyclerViewActivity() })
        mTextViewTitle = findViewById(R.id.textViewTitle)
        mTextViewMetadataDate = findViewById(R.id.textViewMetadataDate)

        // Initialize with a new request when app is opened.
        mQueue = Volley.newRequestQueue(this)
        jsonParse()
        mButtonParse!!.setOnClickListener(View.OnClickListener {
            mTextViewSuggest!!.setText("")
            jsonParse()
        })
//        mButtonSelectDateButton = findViewById(R.id.selectDateButton)
        mButtonSelectDateButton!!.setOnClickListener(View.OnClickListener {
            val datePicker: DialogFragment = DatePickerFragment()
            datePicker.show(supportFragmentManager, "date picker")
        })
//        mImageViewAddIntoFavorites = findViewById(R.id.addIntoFavorites)
        mImageViewAddIntoFavorites!!.setOnClickListener(View.OnClickListener { saveDataIntoFavoriteList() })
        loadDataIntoFavoriteList()
        mTextViewDatePicker!!.setText("\"Select Date\" to get today's picture!")
    }

    // Shared preferences methods
    private fun saveDataIntoFavoriteList() {
        val sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE)
        mUrlRequestForJsonFavorites = mUrlRequestForJson
        mFavoriteList.add(mUrlRequestForJsonFavorites)
        setmFavoriteList(mUrlRequestForJsonFavorites)
        val editor = sharedPreferences.edit()
        editor.putString(URL_JSON, mUrlRequestForJson)
        Log.d(TAG, "mUrlRequestForJsonFavorites: " + mUrlRequestForJsonFavorites)
        editor.apply()
        PrefConfig.saveData(applicationContext, mUrlRequestForJsonFavorites)
        Toast.makeText(this@MainActivity, "Added to Favorites!", Toast.LENGTH_SHORT).show()
    }

    private fun loadDataIntoFavoriteList() {
        val sharedPreferences = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE)
        mUrlRequestForJsonFavorites = sharedPreferences.getString(URL_JSON, "true")
        Log.d(TAG, "mUrlRequestForJsonFavorites: " + mUrlRequestForJsonFavorites)
    }

    // Display date, explanation, Title and the image / video of the day
    // Default usage
    // date format is YYYY-MM-DD
    // https://api.nasa.gov/planetary/apod?api_key=XqN37uhbQmRUqsm2nTFk4rsugtM2Ibe0YUS9HDE3
    private fun jsonParse() {
        Log.d(TAG, "mUrlRequestForJsonLastActive: " + mUrlRequestForJsonLastActive)
        if (mCurrentDateFormatInput != null) {
            // Adding dates
            mUrlRequestForJson =
                mUrlRequestDefaultKey + "&" + "date" + "=" + mCurrentDateFormatInput
            mUrlRequestForJsonLastActive =
                mUrlRequestDefaultKey + "&" + "date" + "=" + mCurrentDateFormatInput
        } else {
            // If the Last Active value is null.
            mUrlRequestForJson =
                if (mUrlRequestForJsonLastActive == "" || mUrlRequestForJsonLastActive == null) {
                    mUrlRequestDefaultKey
                } else {
                    mUrlRequestForJsonLastActive
                }
        }
        val request = JsonObjectRequest(
            Request.Method.GET, mUrlRequestForJson, null,
            { response ->
                try {
                    Log.d(TAG, "mUrlRequestForJson: $mUrlRequestForJson")
                    val explanation = response.getString("explanation")
                    val date = response.getString("date")
                    val title = response.getString("title")
                    val imageUrl = response.getString("url")
                    mTextViewTitle!!.text = title
                    mTextViewMetadataDate!!.text = "Taken on: $date"
                    mTextViewExplanation!!.text = explanation
                    Log.d(TAG, "Image url: $imageUrl")

                    // Attempt to resize the image to fit exactly into the target
                    if (imageUrl == null) {
                        Toast.makeText(
                            this@MainActivity,
                            "Image not received. Try again.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                    Picasso.get().load(imageUrl).into(mImageView)
                } catch (e: JSONException) {
                    Log.d(TAG, "JSONException: ")
                    e.printStackTrace()
                }
            }
        ) { error ->
            Log.d(TAG, "JsonObject Error Response$error")
            if (error is TimeoutError) {
                Toast.makeText(
                    this@MainActivity,
                    "Unable to fetch from APOD. Try again.",
                    Toast.LENGTH_SHORT
                ).show()
                mButtonParse!!.isEnabled = true
            } else if (error is NoConnectionError) {
                Toast.makeText(
                    this@MainActivity,
                    "Please connect to Internet and try again.",
                    Toast.LENGTH_SHORT
                ).show()
                mButtonParse!!.isEnabled = false
            }
            error.printStackTrace()
            mButtonSelectDateButton!!.isEnabled = false
            mButtonDarkMode!!.isEnabled = false
            mImageViewSelectSecondActivity!!.isEnabled = false
            mImageViewAddIntoFavorites!!.isEnabled = false
            mTextViewExplanation!!.text = "No Internet!"
        }
        request.retryPolicy = DefaultRetryPolicy(50, 5, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT)
        mQueue!!.add(request)
    }

    // Set Date here: YY-MM-DD
    override fun onDateSet(view: DatePicker, year: Int, month: Int, dayOfMonth: Int) {
        val c = Calendar.getInstance()
        c[Calendar.YEAR] = year
        c[Calendar.MONTH] = month
        c[Calendar.DAY_OF_MONTH] = dayOfMonth
        Log.d(TAG, "onDateSet: " + year + ":" + (month + 1) + ":" + dayOfMonth)
        mCurrentDateString = DateFormat.getDateInstance().format(c.time)
        Log.d(TAG, "currentDateString: $mCurrentDateString")
        val monthString =
            if ((month + 1) / 10 <= 1) Integer.toString(month + 1) else "0" + (month + 1)
        val dayOfMonthString =
            if (dayOfMonth / 10 >= 1) Integer.toString(dayOfMonth) else "0$dayOfMonth"
        mCurrentDateFormatInput = "$year-$monthString-$dayOfMonthString"
        Log.d(TAG, "currentDateFormatInput: $mCurrentDateFormatInput")
        mTextViewDatePicker!!.text = mCurrentDateString
        mTextViewSuggest!!.text = "Click here to \"View\""
    }

    private fun openRecyclerViewActivity() {
        val intent = Intent(this, ExampleRecyclerViewActivity::class.java)
        startActivity(intent)
    }

    override fun onDestroy() {
        Log.d(TAG, "Saving last request: " + mUrlRequestForJsonLastActive)
        mUrlRequestForJsonLastActive?.let { PrefConfig.saveLastActive(applicationContext, it) }
        super.onDestroy()
    }

    companion object {
        const val SHARED_PREFS = "sharedPrefs"
        const val URL_JSON = "urlJson"
        const val NIGHT_MODE = "nightMode"
        private const val mUrlRequestDefaultKey =
            "https://api.nasa.gov/planetary/apod?api_key=XqN37uhbQmRUqsm2nTFk4rsugtM2Ibe0YUS9HDE3"

        // This value will be given to RecyclerviewList for maintaining favorites
        protected var mUrlRequestForJsonFavorites: String? = null

        // This value will be used when user opens the app again and corresponding date will be shown
        protected var mUrlRequestForJsonLastActive: String? = null
        protected var mFavoriteList: MutableSet<String?> = HashSet()
    }
}