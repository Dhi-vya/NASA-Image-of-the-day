package com.example.imageoftheday

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.RequestQueue
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley
import org.json.JSONException

class ExampleRecyclerViewActivity : AppCompatActivity(), ExampleAdaptor.OnItemClickListener {
    private val TAG = "ExampleRecyclerViewActivity"
    private var mTextViewEmptyListUpdate: TextView? = null
    private var mRecyclerView: RecyclerView? = null
    private var mExampleAdaptor: ExampleAdaptor? = null
    private var mExampleItemList: ArrayList<ExampleItem>? = null
    private var mRequestQueue: RequestQueue? = null

    // Declare and initialize mFavoriteList
    private var mFavoriteList: HashSet<Any>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_example_recycler_view)
//        mTextViewEmptyListUpdate = findViewById(R.id.emptyListUpdate)
//        mRecyclerView = findViewById(R.id.recyclerView)
        // Don't change width and height and load all images in fixed view
        mRecyclerView!!.setHasFixedSize(true)
        mRecyclerView!!.setLayoutManager(LinearLayoutManager(this))
        mExampleItemList = ArrayList()
        mRequestQueue = Volley.newRequestQueue(this)
        if (mExampleItemList!!.size == 0) {
            mTextViewEmptyListUpdate!!.setText("Seems empty, add your favorites here!")
        }
//        mFavoriteList = PrefConfig.readListFromPref(applicationContext)
        if (mFavoriteList == null) {
            mFavoriteList = HashSet<Any>()
        }
        parseJSON()
    }

    private fun parseJSON() {
        for (requestJSON in mFavoriteList!!) {
            val request = JsonObjectRequest(
                Request.Method.GET, requestJSON.toString(), null,
                { response ->
                    try {
                        val date = response.getString("date")
                        val title = response.getString("title")
                        val imageUrl = response.getString("url")
                        val values = date.split("-".toRegex()).dropLastWhile { it.isEmpty() }
                            .toTypedArray()
                        val day = values[0].toInt()
                        val month = values[1].toInt()
                        val year = values[2].toInt()
                        mUrlRequestForJsonRemoveFavorites = requestJSON.toString()
                        Log.d(TAG, "requestJSON: $requestJSON")
                        mExampleItemList!!.add(ExampleItem(imageUrl, title, date))
                        // fill adaptor with the data
                        mExampleAdaptor = ExampleAdaptor(
                            this@ExampleRecyclerViewActivity,
                            mExampleItemList!!
                        )
                        mRecyclerView!!.adapter = mExampleAdaptor
                        mExampleAdaptor!!.setOnItemClickListener(this@ExampleRecyclerViewActivity)
                        mTextViewEmptyListUpdate!!.text = ""
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            ) { error ->
                Toast.makeText(
                    this@ExampleRecyclerViewActivity,
                    error.message,
                    Toast.LENGTH_SHORT
                ).show()
                error.printStackTrace()
            }
            mRequestQueue!!.add(request)
        }
    }

    override fun onItemClick(position: Int) {
        val detailIntent = Intent(this, DetailActivity::class.java)
        val clickedItem = mExampleItemList!![position]
        detailIntent.putExtra(EXTRA_URL, clickedItem.imageUrl)
        detailIntent.putExtra(EXTRA_TITLE, clickedItem.title)
        detailIntent.putExtra(EXTRA_DATE, clickedItem.date)
        startActivity(detailIntent)
    }

    override fun onDeleteItem(position: Int) {
        removeItem(position)
        mUrlRequestForJsonRemoveFavorites?.let { mFavoriteList!!.remove(it) }
        PrefConfig.updateData(applicationContext)
    }

    private fun removeItem(position: Int) {
        mExampleItemList!!.removeAt(position)
        mExampleAdaptor!!.notifyItemRemoved(position)
        if (mExampleItemList!!.size == 0) {
            mTextViewEmptyListUpdate!!.text = "Seems empty, add your favorites here!"
        }
    }

    companion object {
        const val EXTRA_URL = "imageUrl"
        const val EXTRA_TITLE = "title"
        const val EXTRA_DATE = "date"
        protected var mUrlRequestForJsonRemoveFavorites: String? = null
    }
}