package com.example.imageoftheday

import android.app.Notification.EXTRA_TITLE
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.imageoftheday.ExampleRecyclerViewActivity.Companion.EXTRA_DATE
import com.example.imageoftheday.ExampleRecyclerViewActivity.Companion.EXTRA_URL
import com.squareup.picasso.Picasso

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        val intent = intent
        val imageUrl = intent.getStringExtra(EXTRA_URL)
        val title = intent.getStringExtra(EXTRA_TITLE)
        val dateTaken = intent.getStringExtra(EXTRA_DATE)
        val imageView = findViewById<ImageView>(R.id.imageViewDetail)
        val textViewTitle = findViewById<TextView>(R.id.textViewTitleDetail)
        val textViewDateTaken = findViewById<TextView>(R.id.textViewDateTakenDetail)
        Picasso.get().load(imageUrl).into(imageView)
        textViewTitle.text = title
        textViewDateTaken.text = dateTaken
    }
}