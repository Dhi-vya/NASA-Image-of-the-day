package com.example.imageoftheday

class ExampleItem(val imageUrl: String, val title: String, val date: String)

