package com.example.imageoftheday

import android.content.Context
import android.preference.PreferenceManager
import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object PrefConfig {
    private const val TAGPref = "PrefConfig"
    const val LIST_KEY = "list_key"
    const val URL_JSON_LAST_ACTIVE = "urlJsonLastActive"

    // Declare and initialize mFavoriteList as an empty set
    private var mFavoriteList: MutableSet<String> = mutableSetOf()

    // Declare and initialize mUrlRequestForJsonLastActive as an empty string
    private var mUrlRequestForJsonLastActive: String = ""

    fun saveData(context: Context?, string: String?) {
        // Convert list to Json string
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        if (string != null) {
            mFavoriteList.add(string)
        }
        val json = gson.toJson(mFavoriteList)
        editor.putString(LIST_KEY, json)
        Log.d(TAGPref, "saveData: $mFavoriteList")
        editor.apply()
    }

    fun readListFromPref(context: Context?): Set<String> {
        val pref = PreferenceManager.getDefaultSharedPreferences(context)
        val jsonString = pref.getString(LIST_KEY, "")
        val gson = Gson()
        val type = object : TypeToken<Set<String?>?>() {}.type
        val stringList = gson.fromJson<Set<String>>(jsonString, type)
        Log.d(TAGPref, "readListFromPref: $stringList")
        return stringList
    }

    fun updateData(context: Context?) {
        // Convert list to Json string
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = sharedPreferences.edit()
        val gson = Gson()
        val json = gson.toJson(mFavoriteList)
        editor.putString(LIST_KEY, json)
        editor.apply()
        Log.d(TAGPref, "updateData: $mFavoriteList")
    }

    fun saveLastActive(context: Context?, string: String) {
        // Convert list to Json string
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        val editor = sharedPreferences.edit()
        mUrlRequestForJsonLastActive = string
        editor.putString(URL_JSON_LAST_ACTIVE, string)
        Log.d(TAGPref, "saveLastActive: $mUrlRequestForJsonLastActive")
        editor.apply()
    }

    fun retrieveLastRequest(context: Context?): String? {
        val pref = PreferenceManager.getDefaultSharedPreferences(context)
        val string = pref.getString(URL_JSON_LAST_ACTIVE, "")
        Log.d(TAGPref, "Last Request string: $string")
        return string
    }
}
