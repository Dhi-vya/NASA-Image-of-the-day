package com.example.imageoftheday

import android.app.DatePickerDialog
import android.app.DatePickerDialog.OnDateSetListener
import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment
import java.util.*

class DatePickerFragment : DialogFragment() {
    var c = Calendar.getInstance()
    var year = c[Calendar.YEAR]
    var month = c[Calendar.MONTH]
    var day = c[Calendar.DAY_OF_MONTH]

    // Account for Date Picker to show till today's date.
    private val oneDayBefore = 1 * 24 * 60 * 60 * 1000L
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val datePickerDialog =
            DatePickerDialog(requireActivity(), activity as OnDateSetListener?, year, month, day)
        datePickerDialog.datePicker.maxDate = System.currentTimeMillis() - oneDayBefore
        return datePickerDialog
    }
}




