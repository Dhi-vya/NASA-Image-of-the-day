package com.example.imageoftheday

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class ExampleAdaptor(private val mContext: Context, exampleList: ArrayList<ExampleItem>) :
    RecyclerView.Adapter<ExampleAdaptor.ExampleViewHolder>() {
    private val mExampleList: ArrayList<ExampleItem>
    private var mListener: OnItemClickListener? = null

    // Create an interface to open an image to Detail Activity
    interface OnItemClickListener {
        fun onItemClick(position: Int) // Call this after adapter has been created, setAdapter()
        fun onDeleteItem(position: Int) // Call this after adapter has been created, setAdapter()
    }

    fun setOnItemClickListener(listener: OnItemClickListener?) {
        mListener = listener
    }

    init {
        mExampleList = exampleList
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ExampleViewHolder {
        val v: View = LayoutInflater.from(mContext).inflate(R.layout.example_item, parent, false)
        return ExampleViewHolder(v)
    }

    // Get list of current items here
    override fun onBindViewHolder(holder: ExampleViewHolder, position: Int) {
        val currentItem: ExampleItem = mExampleList[position]
        val imageUrl: String = currentItem.imageUrl
        val title: String = currentItem.title
        val dateTaken: String = currentItem.date

        // Set each view here
        holder.mTextViewTitle.text = title
        holder.mTextViewDate.text = "Taken on: $dateTaken"
        Picasso.get().load(imageUrl).fit().centerInside().into(holder.mImageView)
    }

    override fun getItemCount(): Int {
        return mExampleList.size
    }

    inner class ExampleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var mImageView: ImageView
        var mTextViewTitle: TextView
        var mTextViewDate: TextView
        var mDeleteItem: ImageView

        init {
            mImageView = itemView.findViewById(R.id.imageRecyclerView)
            mTextViewTitle = itemView.findViewById(R.id.textRecyclerViewTitle)
            mTextViewDate = itemView.findViewById(R.id.textRecyclerViewDate)
            mDeleteItem = itemView.findViewById(R.id.deleteItem)
            itemView.setOnClickListener {
                if (mListener != null) {
                    // Get the position in Recycler View List
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        mListener!!.onItemClick(position)
                    }
                }
            }
            mDeleteItem.setOnClickListener {
                if (mListener != null) {
                    // Get the position in Recycler View List
                    val position = adapterPosition
                    if (position != RecyclerView.NO_POSITION) {
                        mListener!!.onDeleteItem(position)
                    }
                }
            }
        }
    }
}
